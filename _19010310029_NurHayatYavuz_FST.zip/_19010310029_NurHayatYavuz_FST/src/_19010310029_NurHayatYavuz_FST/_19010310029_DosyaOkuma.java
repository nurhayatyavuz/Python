package _19010310029_NurHayatYavuz_FST;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class _19010310029_DosyaOkuma {
	
		public static void main(String[] args) {
	        String dosyaAdi = "FST.txt"; 
	        try {
	           
	            FileReader dosyaOkuyucu = new FileReader(dosyaAdi);
	            BufferedReader bufferedReader = new BufferedReader(dosyaOkuyucu);

	            String satir;
	            while ((satir = bufferedReader.readLine()) != null) {
	               
	                System.out.println(satir); 
	            }

	           
	            dosyaOkuyucu.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	            System.err.println("Dosya okuma hatas�: " + e.getMessage());
	        }
	       
	    }
			 
	}



