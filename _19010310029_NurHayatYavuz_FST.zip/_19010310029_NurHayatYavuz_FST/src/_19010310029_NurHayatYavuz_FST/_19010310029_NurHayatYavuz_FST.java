package _19010310029_NurHayatYavuz_FST;

import java.util.Scanner;

public class _19010310029_NurHayatYavuz_FST {
	
	    private static final String Q1 = "q1";
	    private static final String Q2 = "q2";
	    private static final String Q3 = "q3";

	    private StringBuilder cikti;
	    private String mevcutDurum;

	    public _19010310029_NurHayatYavuz_FST() {
	        cikti = new StringBuilder();
	        mevcutDurum = Q1;
	        initializeDurumlar();
	    }

	    private void initializeDurumlar() {
	        
	    }

	    public void siradakiDurumuHesapla(char karakter) {
	        if (mevcutDurum.equals(Q1)) {
	            if (karakter == '0' || karakter == '1') {
	                mevcutDurum = Q1;
	                cikti.append('0');
	            } else if (karakter == '2') {
	                mevcutDurum = Q2;
	                cikti.append('1');
	            } else {
	                mevcutDurum = Q3;
	            }
	        } else if (mevcutDurum.equals(Q2)) {
	            if (karakter == '0') {
	                mevcutDurum = Q1;
	                cikti.append('0');
	            } else if (karakter == '1' || karakter == '2') {
	                mevcutDurum = Q2;
	                cikti.append('1');
	            } else {
	                mevcutDurum = Q3;
	            }
	        }
	        
	    }

	    public String getCikti() {
	        return cikti.toString();
	    }

	    public String getSonucCikti() {
	        if (mevcutDurum.equals(Q1)) {
	            return null;
	        } else if (mevcutDurum.equals(Q2)) {
	            return null;
	        } else {
	            return "Durum Yok";
	        }
	    }

	    public static void main(String[] args) {
	        try (Scanner scanner = new Scanner(System.in)) {
				_19010310029_NurHayatYavuz_FST makine;

				for (int i = 0; i < 2; i++) {
				    makine = new _19010310029_NurHayatYavuz_FST();
				    makine.initializeDurumlar();

				    System.out.print("L�tfen bir girdi girin: ");
				    String kullaniciGirdisi = scanner.nextLine();

				   
				    for (char karakter : kullaniciGirdisi.toCharArray()) {
				        makine.siradakiDurumuHesapla(karakter);
				        System.out.println("Girdi: " + karakter + " Mevcut Durum: " + makine.mevcutDurum);
				    }

				  
				    System.out.println("��kt�: " + makine.getCikti());
				   
				    System.out.println("-------------------------------");
				}
				}
	        }
	    }


